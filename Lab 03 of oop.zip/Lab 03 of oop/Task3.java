class Task3 {
    public static void main(String[] args) {
       
        int[][] mat = {
            {12, 13, 15, 16},
            {11, 110, 121, 17},
            {17, 18, 100, 21}
        };

      System.out.println("----- Matrix ----- ");
  
          
for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print(mat[i][j] + " "); 
            }
            System.out.println(); 
        }
  int sum = 0;

System.out.println();
     System.out.println("-----Divided even numbers of Matrix ----- ");
  
for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {

   if (mat [i][j] % 2 == 0){
  mat[i][j] =  mat[i][j] / 2;
 sum += mat[i][j];
 }
 System.out.print(mat[i][j] + " ");
}
   System.out.println(); 
}


 System.out.println();
    System.out.println("----- Odd numbers of Matrix ----- ");
  for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
	 if (mat [i][j] % 2 != 0){
 System.out.print(mat[i][j] + " ");
}
 
}

   System.out.println();
}
 System.out.println();
    System.out.println("----- Sum of updated numbers of Matrix ----- ");


System.out.println(sum);
}
}
