import java.util.Scanner;

class Task1{
 public static void main(String [] args){
Scanner input = new Scanner(System.in);
System.out.println("Enter the starting range: ");
int from = input.nextInt();
System.out.println("Enter the ending range: ");
int to = input.nextInt();
boolean isprime = false;

for (int num = from; num <= to; num++){
isprime = true;
for(int i = 2; i < num; i++){
if (num %i == 0){
isprime = false;
break;
}

}
 if(isprime){
 System.out.println(num + " ");
}
}
}
}
