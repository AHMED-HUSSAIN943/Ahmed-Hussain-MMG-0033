import java.util.Scanner;

class Task5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        
        boolean[][] seats = {
            {true, false, true, true, false, true, false, false, true},
            {true, true, true, true, false, false, true, false, true},
            {false, false, true, false, false, true, false, true, true},
            {true, true, false, true, false, true, false, false, true},
            {true, false, true, false, true, true, false, true, true},
            {true, false, true, true, false, true, false, true, false},
            {false, true, true, false, false, true, true, false, true}
        };
        System.out.println("Initial seat status:");
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 9; j++) {
                System.out.print((seats[i][j] ? "Reserved" : "Available") + " | ");
            }
            System.out.println();
        }

        int choice;
        do {
	    System.out.println();
            System.out.println("---- Menue for seat resevation ----");
            System.out.println("\n1. Display Available seats");
            System.out.println("2. Reserve a seat");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("\nAvailable seats:");
                    for (int i = 0; i < seats.length; i++) {
                        for (int j = 0; j < seats[i].length; j++) {
                            if (!seats[i][j]) {
                                System.out.print("Row " + i + ", Col " + j + " | ");
                            }
                        }
                    }
                    System.out.println();
                    break;

                case 2:
                    
                    System.out.print("Enter row number (0-6): ");
                    int row = input.nextInt();
                    System.out.print("Enter column number (0-8): ");
                    int col = input.nextInt();

                   
                    if (row < 0 || row >= seats.length || col < 0 || col >= seats[0].length) {
                        System.out.println("Invalid range. Please enter valid row and column numbers.");
                    } else {
                        
                        if (!seats[row][col]) {
                            seats[row][col] = true;  
                            System.out.println("Seat at Row " + row + ", Col " + col + " is now reserved.");
                        } else {
                            System.out.println("The seat at Row " + row + ", Col " + col + " is already reserved.");
                        }
                    }
                    break;

                case 3:
           
                    System.out.println("Exiting the system.");
                    break;

                default:
                    
                    System.out.println("Invalid choice! Please enter a valid option (1-3).");
            }
        } while (choice != 3);

        input.close();  
    }
}
