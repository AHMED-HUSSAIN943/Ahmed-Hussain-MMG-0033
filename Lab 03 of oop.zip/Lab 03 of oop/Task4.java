import java.util.Scanner;

class Task4{
 public static void main(String [] args){
Scanner input = new Scanner(System.in);

int[] arr = { 1, 4, 9, 16, 25, 36, 49, 64, 81, 0};
    int sum = 0;
   
 for (int i = 0; i < 9; i++){

   System.out.print(arr[i] + ",");

    if(arr[i] % 2 != 0){
     sum += arr[i];
  } 
}
System.out.println();
  System.out.println("The sum of odd numbers:" + sum);

}
}