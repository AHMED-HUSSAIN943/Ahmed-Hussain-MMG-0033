import java.util.Scanner;

public class Task8{
 public static void main(String [] args){

Scanner scanner = new Scanner (System.in);

System.out.println("Enter speed in mph: ");
float sinm = scanner.nextFloat();

System.out.println(sinm + " mph is equavalent to: " + sinm*1.60934 + " kph");


}
}