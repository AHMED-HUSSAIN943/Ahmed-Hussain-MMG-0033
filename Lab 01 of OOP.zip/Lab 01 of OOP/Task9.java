import java.util.Scanner;
 
 class Task9{
 public static void main(String [] args){

 Scanner scanner = new Scanner(System.in);
 
System.out.println("-- Simple Calculator --");
System.out.println("1.Addition.");
System.out.println("2.Suptraction.");
System.out.println("3.Multiplication.");
System.out.println("4.Division.");
System.out.println("Enter Your choice: ");

int choice = scanner.nextInt();

if(choice == 1){
System.out.println("Enter First num:");  
int num1 = scanner.nextInt();
System.out.println("Enter second num:"); 
 int num2 = scanner.nextInt();
System.out.println("Addition is:" + num1 + num2);
}

else if(choice == 2){
System.out.println("Enter First num:");  
int num1 = scanner.nextInt();
System.out.println("Enter second num:");  
int num2 = scanner.nextInt();
System.out.println( num1 - num2);
}

else if(choice == 3){
System.out.println("Enter First num:");  
int num1 = scanner.nextInt();
System.out.println("Enter second num:");  
int num2 = scanner.nextInt();
System.out.println("Multiplication is:" + num1 * num2);
}

else if(choice == 4){
System.out.println("Enter First num:"); 
int num1 = scanner.nextInt();
 System.out.println("Enter second num:");
int num2 = scanner.nextInt();
System.out.println("Division is:" + num1 / num2);
}

else{
System.out.println("Invalid choice");
}

}
}