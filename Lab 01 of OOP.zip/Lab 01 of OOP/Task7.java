import java.util.Scanner;

public class Task7{
public static void main(String [] args){


System.out.println("==== Calculation of the volume of cylynder ====");
Scanner scanner = new Scanner(System.in);
System.out.println("Enter radius of cylynder: ");
float radius = scanner.nextFloat();
System.out.println("Enter height of cylynder: ");
double height = scanner.nextDouble();
float sr = radius*radius;
System.out.println("The volume of cylynder is V = "+ 3.14159*sr*height);


}
}