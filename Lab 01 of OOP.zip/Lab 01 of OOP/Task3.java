class Task3{

public static void main(String [] args){
 int id = 33; 
String name = "Ahmed Hussain";
 int age = 19;
 int gradePoints = 90;
 double average = 85.4;
 String gender = "M";
 boolean foreigner = false;
System.out.println(id);
System.out.println(name);
System.out.println(age);
System.out.println(gradePoints);
System.out.println(average);
System.out.println(gender);
System.out.println(foreigner);
}
}