import java.util.Scanner;

class Task6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your age: ");
        int age = scanner.nextInt();

        System.out.println((age >= 18) ? "You are eligible to vote" : "You are not eligible to vote");

        scanner.close();
    }
}