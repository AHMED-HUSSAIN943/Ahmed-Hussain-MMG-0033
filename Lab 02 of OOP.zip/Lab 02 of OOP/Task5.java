import java.util.Scanner;

class Task5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create and initialize the matrix
        int[][] mat = {
            {1, 1, 0, 0, 1},
            {1, 0, 1, 0, 1},
            {1, 0, 0, 1, 1},
            {1, 0, 0, 0, 1}
        };

        // Print the matrix
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
        }

        boolean hasN = false; // Example name for checking a pattern
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                if (mat[i][j] == 1) { 
                    hasN = true;
                    break;
                }
            }
            if (hasN) break; // Break outer loop if found
        }

        if (hasN) {
            System.out.println("Pattern found in the matrix.");
        } else {
            System.out.println("Pattern not found in the matrix.");
        }

        scanner.close();
    }
}