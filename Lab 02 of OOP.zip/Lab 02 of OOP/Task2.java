import java.util.Scanner;
 class Task2{
public static void main(String [] args){

Scanner scanner = new Scanner(System.in);
int[] integers = new int[10];

System.out.println("Enter the numbers of array: ");
for (int i = 0; i < 10 ; i++){

  integers[i] = scanner.nextInt();

}


int sum = 0;
for(int i = 0; i < 10; i++ ){
System.out.print(integers[i] + ",");
if (integers[i] % 4 == 0){

sum += integers[i];

}

}
System.out.println("Total sum = " + sum);
 
}
}