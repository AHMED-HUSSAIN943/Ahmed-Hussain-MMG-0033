import java.util.Scanner;

class Task4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] arr = new String[6];

        System.out.println("Enter Names of array: ");
        for (int i = 0; i < 6; i++) {
            arr[i] = scanner.nextLine();
        }

        // Print entered names
        for (int i = 0; i < 6; i++) {
            System.out.print(arr[i] + ", ");
        }
        System.out.println(); // For better readability

        // Check if "Ali" is present in the array (ignore case)
        boolean isPresent = false;
        for (int i = 0; i < 6; i++) {
            if (arr[i].equalsIgnoreCase("Ali")) {
                isPresent = true;
                break; // No need to continue checking once found
            }
        }

        if (isPresent) {
            System.out.println("Present.");
        } else {
            System.out.println("Not Present.");
        }

        scanner.close();
    }
}