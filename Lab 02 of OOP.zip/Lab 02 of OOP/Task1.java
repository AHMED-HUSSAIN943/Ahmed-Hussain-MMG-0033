import java.util.Scanner;
 public class Task1{
 public static void main (String [] args) {



char[] consonants = {'b' , 'c' , 'd' , 'f' , 'g' , 'h' , 'j' , 'k' , 'l' , 'm' , 'n' , 'p' , 'q' , 'r' , 's' , 't' , 'v' ,'w' , 'x' , 'y' , 'z'} ;
 Scanner scanner = new Scanner(System.in);
System.out.println("Enter your character: ");
char user_inp = scanner.next().charAt(0);
boolean check = false;
for(int i = 0 ; i < consonants.length ; i++ ){

if(user_inp == consonants[i]){
 check = true;
break;
}
}
 
if (check){
 System.out.println(" consonant");
}
else{
System.out.println( "  not a consonant"); 
}
}
}
